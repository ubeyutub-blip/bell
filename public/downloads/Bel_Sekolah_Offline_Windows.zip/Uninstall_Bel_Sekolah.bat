@echo off
chcp 65001 >nul
title Hapus Instalasi Bel Sekolah Otomatis
color 4F

echo =======================================================================
echo              HAPUS INSTALASI BEL SEKOLAH OTOMATIS
echo =======================================================================
echo.
echo Script ini akan menghapus pintasan Desktop dan file aplikasi lokal.
echo.
set /p CONFIRM="Yakin ingin menghapus? [Y/T]: "
if /I "%CONFIRM%"=="Y" (
    del "%USERPROFILE%\Desktop\Bel Sekolah Otomatis.lnk" 2>nul
    del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Bel Sekolah Otomatis.lnk" 2>nul
    rd /S /Q "%LOCALAPPDATA%\BelSekolahOtomatis" 2>nul
    echo.
    echo [OK] Pintasan dan file aplikasi berhasil dihapus dari komputer ini.
) else (
    echo Pembatalan dilakukan.
)
echo.
pause
