@echo off
chcp 65001 >nul
title Installer Bel Sekolah Otomatis - Offline Windows
color 1F

echo =======================================================================
echo          INSTALLER BEL SEKOLAH OTOMATIS (OFFLINE WINDOWS)
echo =======================================================================
echo.
echo [1/4] Memeriksa file aplikasi...
set "SOURCE_DIR=%~dp0"
set "TARGET_DIR=%LOCALAPPDATA%\BelSekolahOtomatis"
set "DESKTOP_PATH=%USERPROFILE%\Desktop"
set "STARTUP_PATH=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

if not exist "%SOURCE_DIR%index.html" (
    echo [ERROR] File index.html tidak ditemukan!
    echo Pastikan file instalasi lengkap.
    echo.
    pause
    exit /b 1
)

echo [2/4] Memasang file aplikasi ke: %TARGET_DIR% ...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
xcopy /E /Y /I "%SOURCE_DIR%*" "%TARGET_DIR%\" >nul

echo [3/4] Membuat Pintasan Desktop...
set "VBS_SCRIPT=%TEMP%\create_bel_shortcut.vbs"
(
echo Set oWS = WScript.CreateObject("WScript.Shell"^)
echo sLinkFile = "%DESKTOP_PATH%\Bel Sekolah Otomatis.lnk"
echo Set oLink = oWS.CreateShortcut(sLinkFile^)
echo oLink.TargetPath = "%TARGET_DIR%\Buka_Bel_Sekolah.bat"
echo oLink.WorkingDirectory = "%TARGET_DIR%"
echo oLink.IconLocation = "%TARGET_DIR%\favicon.ico, 0"
echo oLink.Description = "Aplikasi Bel Sekolah Otomatis (Offline)"
echo oLink.WindowStyle = 7
echo oLink.Save
) > "%VBS_SCRIPT%"

cscript //nologo "%VBS_SCRIPT%"
del "%VBS_SCRIPT%"

echo [OK] Pintasan Desktop "Bel Sekolah Otomatis" berhasil dibuat!
echo.

echo [4/4] Konfigurasi Auto-Start saat Komputer Menyala
echo -----------------------------------------------------------------------
echo Apakah Anda ingin Bel Sekolah otomatis langsung menyala saat komputer
echo dinyalakan di pagi hari (Sangat cocok untuk PC Piket / Tata Usaha)?
set /p AUTOSTART="Aktifkan Auto-Start di pagi hari? [Y/T / Tekan Enter untuk Ya]: "

if /I not "%AUTOSTART%"=="T" (
    set "VBS_STARTUP=%TEMP%\create_bel_startup.vbs"
    (
    echo Set oWS = WScript.CreateObject("WScript.Shell"^)
    echo sLinkFile = "%STARTUP_PATH%\Bel Sekolah Otomatis.lnk"
    echo Set oLink = oWS.CreateShortcut(sLinkFile^)
    echo oLink.TargetPath = "%TARGET_DIR%\Buka_Bel_Sekolah.bat"
    echo oLink.WorkingDirectory = "%TARGET_DIR%"
    echo oLink.IconLocation = "%TARGET_DIR%\favicon.ico, 0"
    echo oLink.Description = "Auto Start Bel Sekolah Otomatis"
    echo oLink.WindowStyle = 7
    echo oLink.Save
    ) > "%VBS_STARTUP%"

    cscript //nologo "%VBS_STARTUP%"
    del "%VBS_STARTUP%"
    echo [OK] Auto-Start aktif! Setiap PC dinyalakan, Bel Sekolah otomatis aktif.
)

echo.
echo =======================================================================
echo                 INSTALASI OFFLINE SELESAI DENGAN SUKSES!
echo =======================================================================
echo.
echo Pintasan telah dibuat di Desktop Windows Anda.
echo Aplikasi dapat beroperasi 100%% OFFLINE tanpa kuota atau kabel internet.
echo.
echo Tekan sembarang tombol untuk membuka Bel Sekolah Otomatis sekarang...
pause >nul

start "" "%TARGET_DIR%\Buka_Bel_Sekolah.bat"
exit
