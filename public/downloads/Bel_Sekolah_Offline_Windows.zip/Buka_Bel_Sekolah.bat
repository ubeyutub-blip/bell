@echo off
chcp 65001 >nul
title Membuka Bel Sekolah Otomatis (Offline)...
cd /d "%~dp0"

if not exist "%~dp0index.html" (
    echo [ERROR] File index.html tidak ditemukan!
    pause
    exit /b 1
)

:: Jalankan server lokal offline mandiri via PowerShell di latar belakang
start /min "" powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0run_server_offline.ps1"

:: Beri jeda 1 detik untuk inisialisasi server lokal
timeout /t 1 /nobreak >nul

:: Buka Microsoft Edge dalam mode App Standalone
start "" msedge.exe --app="http://127.0.0.1:5858/" 2>nul
if %ERRORLEVEL% equ 0 exit

:: Buka Google Chrome dalam mode App Standalone
start "" chrome.exe --app="http://127.0.0.1:5858/" 2>nul
if %ERRORLEVEL% equ 0 exit

:: Browser default
start "" "http://127.0.0.1:5858/"
exit
