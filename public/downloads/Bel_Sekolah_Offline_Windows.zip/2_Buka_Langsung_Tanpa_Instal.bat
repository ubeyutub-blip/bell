@echo off
chcp 65001 >nul
title Bel Sekolah Otomatis (Mode Portable Flashdisk)
cd /d "%~dp0"
call "%~dp0Buka_Bel_Sekolah.bat"
